package com.maike.entity;

public class StuGrade {
	private String id;
	private String stuid;
	private String subjectid;
	private String subjectscore;
	private String credit;
	private String examtype;
	private String yearofstudy;
	private String examteam;
	private String create_time;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getStuid() {
		return stuid;
	}
	public void setStuid(String stuid) {
		this.stuid = stuid;
	}
	public String getSubjectid() {
		return subjectid;
	}
	public void setSubjectid(String subjectid) {
		this.subjectid = subjectid;
	}
	public String getSubjectscore() {
		return subjectscore;
	}
	public void setSubjectscore(String subjectscore) {
		this.subjectscore = subjectscore;
	}
	public String getCredit() {
		return credit;
	}
	public void setCredit(String credit) {
		this.credit = credit;
	}
	public String getCreate_time() {
		return create_time;
	}
	public void setCreate_time(String create_time) {
		this.create_time = create_time;
	}
	public String getExamtype() {
		return examtype;
	}
	public void setExamtype(String examtype) {
		this.examtype = examtype;
	}
	public String getYearofstudy() {
		return yearofstudy;
	}
	public void setYearofstudy(String yearofstudy) {
		this.yearofstudy = yearofstudy;
	}
	public String getExamteam() {
		return examteam;
	}
	public void setExamteam(String examteam) {
		this.examteam = examteam;
	}
	
}
