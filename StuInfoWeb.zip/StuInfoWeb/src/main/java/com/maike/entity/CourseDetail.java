package com.maike.entity;

public class CourseDetail {
	private String id;
	private String subjectid;
	private String teachcourseid;
	private String teachid;
	private String coursehour;
	private String coursecontent;
	private String courseresource;
	private String create_time;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSubjectid() {
		return subjectid;
	}
	public void setSubjectid(String subjectid) {
		this.subjectid = subjectid;
	}
	public String getTeachcourseid() {
		return teachcourseid;
	}
	public void setTeachcourseid(String teachcourseid) {
		this.teachcourseid = teachcourseid;
	}
	public String getTeachid() {
		return teachid;
	}
	public void setTeachid(String teachid) {
		this.teachid = teachid;
	}
	public String getCoursehour() {
		return coursehour;
	}
	public void setCoursehour(String coursehour) {
		this.coursehour = coursehour;
	}
	public String getCoursecontent() {
		return coursecontent;
	}
	public void setCoursecontent(String coursecontent) {
		this.coursecontent = coursecontent;
	}
	public String getCourseresource() {
		return courseresource;
	}
	public void setCourseresource(String courseresource) {
		this.courseresource = courseresource;
	}
	public String getCreate_time() {
		return create_time;
	}
	public void setCreate_time(String create_time) {
		this.create_time = create_time;
	}
}
